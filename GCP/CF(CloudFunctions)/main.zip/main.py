import nltk
from nltk.tokenize import word_tokenize
import re
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')

def stem_sentence(sentence):
    stemmer = PorterStemmer()
    words = word_tokenize(sentence)
    stemmed_words = [stemmer.stem(word) for word in words]
    stemmed_sentence = " ".join(stemmed_words)
    return stemmed_sentence
def preprocess_sentence(sentence):
    sentence = re.sub(r'[^\w\s]', '', sentence)
    sentence = sentence.lower()
    stop_words = set(stopwords.words('english'))
    words = nltk.word_tokenize(sentence)
    filtered_sentence = [word for word in words if word not in stop_words]
    sentence = ' '.join(filtered_sentence)
    sentence=stem_sentence(sentence)
    return sentence

def process(request):
    if request.args and 'sentence' in request.args:
        return preprocess_sentence(request.args.get('sentence'))
    else:
        return f'Sentence arg\'s is empty.'
